## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
set.seed(96)

## ----Librerías utilizadas, include=FALSE--------------------------------
##LIBRERIAS PARA MAC
library("caret", lib.loc="/Library/Frameworks/R.framework/Versions/3.3/Resources/library")
library("AppliedPredictiveModeling",lib.loc="/Library/Frameworks/R.framework/Versions/3.3/Resources/library") 
library("e1071", lib.loc="/Library/Frameworks/R.framework/Versions/3.3/Resources/library") 
library("leaps", lib.loc="/Library/Frameworks/R.framework/Versions/3.3/Resources/library")
library("glmnet", lib.loc="/Library/Frameworks/R.framework/Versions/3.3/Resources/library")
library("randomForest", lib.loc="/Library/Frameworks/R.framework/Versions/3.3/Resources/library")
library("neuralnet", lib.loc="/Library/Frameworks/R.framework/Versions/3.3/Resources/library")
library("pracma", lib.loc="/Library/Frameworks/R.framework/Versions/3.3/Resources/library")
library("gbm", lib.loc="/Library/Frameworks/R.framework/Versions/3.3/Resources/library")


##LIBRERIAS PARA WINDOWS
#library("AppliedPredictiveModeling", lib.loc="~/R/win-library/3.3")
#library("caret", lib.loc="~/R/win-library/3.3")
#library("e1071", lib.loc="~/R/win-library/3.3")
#library("glmnet", lib.loc="~/R/win-library/3.3")
#library("leaps", lib.loc="~/R/win-library/3.3")
#library("randomForest", lib.loc="~/R/win-library/3.3")
#library("neuralnet", lib.loc="~/R/win-library/3.3")
#library("pracma", lib.loc="~/R/win-library/3.3")
#library("gbm", lib.loc="~/R/win-library/3.3")

## ----Lectura del data set: Parkinson-------------------------------------
# Leemos los datos
Parkinson = read.csv("./datos/Parkinsons Telemonitoring.csv")
# Quitamos la columna que indica el numero de paciente
Parkinson = Parkinson[,!colnames(Parkinson)=="subject."]
Parkinson = Parkinson[,!colnames(Parkinson)=="motor_UPDRS"]


## ----Creacion de particiones---------------------------------------------
# Creacion de particiones
set.seed(96)
porcentajeMuestrasTrain = 0.8
train = sample(nrow(Parkinson), round(nrow(Parkinson)*porcentajeMuestrasTrain))
Parkinson.Train = Parkinson[train,]
Parkinson.Test = Parkinson[-train,]

## ----Preprocesado del dataset original-----------------------------------
# Preprocesado automatico
objetoTrans = preProcess(Parkinson.Train,
                         method = c("BoxCox", "center", "scale"))
Parkinson.TrainProcessed = predict(objetoTrans, Parkinson.Train)

# Comprobamos que no exista ninguna componente con varianza 0
nearZeroVar(Parkinson.TrainProcessed)


## ----Seleccion de modelos con Regsubsets: variable respuesta-------------
# Selección de los mejores atributos:
pruebaRegSubsets = regsubsets(total_UPDRS ~ . , data=Parkinson.TrainProcessed, 
                               method = "exhaustive")
summary(pruebaRegSubsets)

## ----Modelos de Regresión Lineal----------------------------------------
# Aprendizaje de modelos:
modeloLineal1 = lm(total_UPDRS ~ age + HNR + DFA, data = Parkinson.TrainProcessed)
modeloLineal2 = lm(total_UPDRS ~ age + Shimmer.DDA + sex + HNR + DFA,
                   data = Parkinson.TrainProcessed)
modeloLineal3 = lm(total_UPDRS ~ age + sex + Jitter.Abs. + Jitter.DDP + Shimmer.APQ5
                   + Shimmer.APQ11 + HNR + DFA, data = Parkinson.TrainProcessed)
modeloLineal4 = lm(total_UPDRS ~ ., data = Parkinson.TrainProcessed)

## ----Funcion para evaluar un modelo 1------------------------------------
evaluacionModelo = function(modeloTrain, datosTest, varRespuesta, indiceModelo)
{
  # Calculamos la probabilidad del modelo lineal
  predTest = predict(modeloTrain, data.frame(datosTest), type="response")
  # Calculo del Eout con el modelo lineal
  Eval = mean((predTest - varRespuesta)^2)
  
  print(sprintf("MSE del modelo %i --> %f", indiceModelo, Eval))
  Eval
}

## ----preProcesado de los datos-------------------------------------------
# Preprocesado datos de Test
objetoTrans_Test = preProcess(Parkinson.Test,
                         method = c("BoxCox", "center", "scale"))
Parkinson.TestProcessed = predict(objetoTrans_Test, Parkinson.Test)

## ----Evaluacion de los modelos obtenidos---------------------------------
# Evaluación de modelos ajustados
e1 = evaluacionModelo(modeloLineal1, Parkinson.TestProcessed,
                      Parkinson.TestProcessed$total_UPDRS, 1)
e2 = evaluacionModelo(modeloLineal2, Parkinson.TestProcessed,
                      Parkinson.TestProcessed$total_UPDRS, 2)
e3 = evaluacionModelo(modeloLineal3, Parkinson.TestProcessed,
                      Parkinson.TestProcessed$total_UPDRS, 3)
e4 = evaluacionModelo(modeloLineal4, Parkinson.TestProcessed,
                      Parkinson.TestProcessed$total_UPDRS, 4)


## ----Modelos de Regresión Lineal con transoformaciones no lineales------
# Ajustes de modelos con transformaciones no lineales
modeloLinealT1 = lm(total_UPDRS ~ I(age^3) + I(HNR^3) + I(DFA^3),
                    data = Parkinson.TrainProcessed)
modeloLinealT2 = lm(total_UPDRS ~ I(age^2) + sex + I(Shimmer.DDA^2) + 
                      I(HNR^2) + I(DFA^2), data = Parkinson.TrainProcessed)
modeloLinealT3 = lm(total_UPDRS ~ age + HNR + DFA + (age*HNR*DFA), 
                    data = Parkinson.TrainProcessed)


## ----Evaluacion de los modelos con transformaciones no lineales obtenidos----

# evaluacion de modelos ajustados mediante transformaciones no lineales
e1 = evaluacionModelo(modeloLinealT1, Parkinson.TestProcessed, 
                      Parkinson.TestProcessed$total_UPDRS, 1)
e2 = evaluacionModelo(modeloLinealT2, Parkinson.TestProcessed,
                      Parkinson.TestProcessed$total_UPDRS, 2)
e3 = evaluacionModelo(modeloLinealT3, Parkinson.TestProcessed,
                      Parkinson.TestProcessed$total_UPDRS, 3)


## ----Funcion para evaluar un modelo--------------------------------------
MSE_Non_Linear = function(prediccion, varRespuesta, indiceModelo,
                          method, pantalla = FALSE)
{
  # Calculo del Eout con el modelo lineal
  Eval = mean((prediccion - varRespuesta)^2)
  if(pantalla){
    print(head(prediccion))
    print(head(varRespuesta))
    print(sprintf("MSE modelo %i de %s --> %f",
                  indiceModelo, method, Eval))
  }
  Eval
}

## ----Función común validación cruzada---------------------------------
CrossValidation = function(dataset, varRespuesta, UnidadesPorCapaOculta = NULL,
                           thres = 0.5,  method = NULL, kernelSVM = "radial" ,
                           gammaSVM = 0.5, numeroArbolesOptimo = 3000, 
                           complejidadOptima = 4, mParam = 5, importancia = T)
{
  set.seed(96)
  #creamos un vector de indices
  indices = 1:length(dataset[,1])
  indices = sample(indices)
  
  #definimos el tamaño de cada uno de las particiones
  ini = 1
  incremento = length(dataset[,1]) / 5 - 1
  fin = incremento
  
  #inicializamos el vector de errores para mas tarde realizar la media
  #de todas los errores de las sucesivas particiones
  MSE = numeric(0)
  resultadoPrediccion = NULL
  mejorModelo = NULL
  mseMejorModelo = 0
  gbm1 = NULL
  for(i in 1:5)
  {
    #creamos las particiones train y test
    train = dataset[-indices[ini:fin],]
    test = dataset[indices[ini:fin],]
    
    #preprocesamos los datos 
    #primero el train
    objetoTrans_Train = preProcess(train,
                         method = c("BoxCox", "center", "scale"))
    trainProcessed = predict(objetoTrans_Train, train)
    
    #despues el test
    objetoTrans_Test = preProcess(test,
                         method = c("BoxCox", "center", "scale"))
    testProcessed = predict(objetoTrans_Test, test)
    
    #indicamos la fórmula a seguir
    f = as.formula(paste(varRespuesta,"~ ."))
    
    if(method == "nn")
    {
        n = names(trainProcessed)
        f = as.formula(paste(paste(varRespuesta, "~"),
                             paste(n[!n %in% varRespuesta],collapse = " + ")))
        nn = neuralnet(f,trainProcessed,UnidadesPorCapaOculta, linear.output = T ,
                       threshold = thres)
        pr.nn <- compute(nn,testProcessed[,1:19])
        resultadoPrediccion = pr.nn$net.result
        testProcessed = as.matrix(testProcessed)
    }
    else if(method == "svm")
    {
         # Creamos el modelo con SVM
        SVM_Model = svm(f, data = trainProcessed, kernel = kernelSVM,gamma = gammaSVM)
        resultadoPrediccion = predict(SVM_Model, data.frame(testProcessed), type="response")
    }
    else if(method == "boosting")
    {
        gbm1 = gbm(f, distribution = "gaussian", data = trainProcessed, 
                   n.trees = numeroArbolesOptimo,interaction.depth = complejidadOptima)
        resultadoPrediccion = predict(gbm1, newdata = testProcessed,
                                      n.trees = numeroArbolesOptimo)
        
       
    }
    else if(method == "rf")
    {
        #calculamos el modelo
        forest = randomForest(f, data = testProcessed, 
        ntree = numeroArbolesOptimo, mtry = mParam, importance = importancia)
        resultadoPrediccion = predict(forest,data.frame(testProcessed),type= "response")
        
    }
  
    MSE = c(MSE,MSE_Non_Linear(resultadoPrediccion,
    testProcessed[,colnames(testProcessed)==varRespuesta],1, method))
    # nos quedamos con el mejor de los modelos
    if(method == "boosting")
    {
      if(i == 1)
      {
        mejorModelo = gbm1
        mseMejorModelo = MSE
      }
      else if((i != 1) && MSE < mseMejorModelo)
      {
        mejorModelo = gbm1
        mseMejorModelo = MSE
      }
      
    }
    
    ini = fin + 1
    fin = fin + incremento
    
  }
  
  Ecv = mean(MSE)
  list(ErrorCV = Ecv, bestGBM = mejorModelo)
}

## ----Creacion de NN------------------------------------------------------
# Entrenamiento de redes neuronales.
nnEcv1 = CrossValidation(Parkinson, "total_UPDRS", UnidadesPorCapaOculta = 5,
                         thres = 5, method = "nn")
nnEcv2 = CrossValidation(Parkinson, "total_UPDRS", UnidadesPorCapaOculta = c(5,3), 
                         thres = 5, method ="nn")
nnEcv3 = CrossValidation(Parkinson, "total_UPDRS", UnidadesPorCapaOculta = c(5,4,3), 
                         thres = 5, method = "nn")

## ----Resultados de las NN------------------------------------------------
print(sprintf("Ecv del primer modelo NN (1 Capa oculta, 5 unidades) -> %f",
               nnEcv1$ErrorCV))
 
print(sprintf("Ecv del segundo modelo NN (2 Capas ocultas, 5 y 3 unidades) -> %f",
              nnEcv2$ErrorCV))
 
print(sprintf("Ecv del segundo modelo NN (3 Capas ocultas, 5,4 y 3 unidades) -> %f",
              nnEcv3$ErrorCV))


## ----Primer Tune---------------------------------------------------------
# Procedemos al calculo del valor gamma optimo para los modelos que
# aprenderemos mediante support vector machine.
set.seed(96)
tuneResult = tune(svm, total_UPDRS ~., data= Parkinson.TrainProcessed, 
                  ranges = list(gamma = seq(0,1,0.1)))
plot(tuneResult)

## ----Segundo Tune--------------------------------------------------------
# Segundo intervalo de prueba para acotar gamma
set.seed(96)
tuneResult_2 = tune(svm, total_UPDRS ~., data= Parkinson.TrainProcessed, 
                    ranges = list(gamma = seq(0.2,0.4,0.02)))
plot(tuneResult_2)
print(tuneResult_2)

## ----Tercer Tune---------------------------------------------------------
# Segundo intervalo de prueba para acotar gamma
set.seed(96)
tuneResult_3 = tune(svm, total_UPDRS ~., data= Parkinson.TrainProcessed, 
                    ranges = list(gamma = seq(0.28,0.32,0.01)))
plot(tuneResult_3)
print(tuneResult_3)

## ----Cross Validation SVM------------------------------------------------
# Cross Validation con el mejor valor de gamma
gamma = 0.29
Ecv_SVM = CrossValidation(Parkinson, "total_UPDRS", gammaSVM = gamma,
                          method = "svm")
print(sprintf("Cross Validation del modelo SVM con mejor gamma estimado -> %f",
              Ecv_SVM$ErrorCV))

## ----Estimacion de mejores parametros------------------------------------

estimacionParametros = function(numeroArboles, complejidadArbol, 
                                train, test, varRespuesta)
{
  #calculamos la formula
  f = as.formula(paste(varRespuesta,"~ ."))
  gbm1 = gbm(f, distribution = "gaussian", data = train, n.trees = numeroArboles,
             interaction.depth = complejidadArbol)
  
  #calculamos las predicciones
  predictions = predict(gbm1, newdata = test, n.trees = numeroArboles)
  
  # CALCULAMOS EL MSE
  mse <- mean((test[,colnames(test)=="total_UPDRS"] - predictions)^2)
  mse
}

## ----Estimacion de parametros--------------------------------------------
#Vamos a utilizar un numero de arboles de 5000, 7500 o 10000 y 
#complejidad de los mismos 4, 5 y 6
numArboles = c(5000,7500,10000)
Errores_C1 = lapply(numArboles, estimacionParametros, complejidadArbol = 4,
                    train = Parkinson.TrainProcessed, test = Parkinson.TestProcessed,
                    varRespuesta = "total_UPDRS")

Errores_C2 = lapply(numArboles, estimacionParametros, complejidadArbol = 5, 
                    train = Parkinson.TrainProcessed, test = Parkinson.TestProcessed,
                    varRespuesta = "total_UPDRS")

Errores_C3 = lapply(numArboles, estimacionParametros, complejidadArbol = 6
                    , train = Parkinson.TrainProcessed, test = Parkinson.TestProcessed,
                    varRespuesta = "total_UPDRS")

## ----Obteniendo los parámetros optimos----------------------------------
# Evaluacion de los mejores modelos
arbolesTotales = rep(numArboles,3)
complexArboles = c(rep(4,3),rep(5,3),rep(6,3))
erroresTotales = c(Errores_C1,Errores_C2,Errores_C3)

plot(cbind(arbolesTotales,erroresTotales) ,type = "p", pch = complexArboles,
     col = complexArboles, main="Estimación Numero de Árboles-complejidad", 
     sub = "X = Complejidad 4, Rombo = 5 ,Triangulo = 6")

## ----Cross Validation Boosting-------------------------------------------
# Cross Validation del mejor modelo de Boosting
EcvBoost = CrossValidation(Parkinson, "total_UPDRS", numeroArbolesOptimo = 5000, 
                           complejidadOptima = 5, method = "boosting")
print(sprintf("Ecv del primer modelo Boosting aprendido -> %f", EcvBoost$ErrorCV))
summary(EcvBoost$bestGBM)

## ----Random Forest CV----------------------------------------------------
#Experientacion para obtener los mejores parametros de random forest
valorM_1 = dim(Parkinson.TrainProcessed)[2]/3
valorM_2 = sqrt(dim(Parkinson.TrainProcessed)[2])
RFEcv = CrossValidation(Parkinson, "total_UPDRS",numeroArbolesOptimo = 100 ,
                        mParam=valorM_1, method = "rf")
print(sprintf("Ecv del modelo 1 con m = sqrt(p) -> %f", RFEcv$ErrorCV))

RFEcv = CrossValidation(Parkinson, "total_UPDRS",numeroArbolesOptimo = 100 , 
                        mParam=valorM_2, method = "rf")
print(sprintf("Ecv del modelo 1 con m = p/3 -> %f", RFEcv$ErrorCV))

RFEcv = CrossValidation(Parkinson, "total_UPDRS",numeroArbolesOptimo = 500 , 
                        mParam=valorM_1, method = "rf")
print(sprintf("Ecv del modelo 2 con m = sqrt(p)o -> %f", RFEcv$ErrorCV))

RFEcv = CrossValidation(Parkinson, "total_UPDRS",numeroArbolesOptimo = 500 , 
                        mParam=valorM_2, method = "rf")
print(sprintf("Ecv del modelo 2 con m = p/3 -> %f", RFEcv$ErrorCV))

RFEcv = CrossValidation(Parkinson, "total_UPDRS",numeroArbolesOptimo = 1000 , 
                        mParam=valorM_1, method = "rf")
print(sprintf("Ecv del modelo 3 con m = sqrt(p) -> %f", RFEcv$ErrorCV))

RFEcv = CrossValidation(Parkinson, "total_UPDRS",numeroArbolesOptimo = 1000 , 
                        mParam=valorM_2, method = "rf")
print(sprintf("Ecv del modelo 3 con m = p/3 -> %f", RFEcv$ErrorCV))

